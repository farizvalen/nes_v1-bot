
## Heroku Buildpack

Klik Untuk Langsumg Nge Deploy Di Heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Haikalbotz/ikalbase)

## For Termux
```bash
termux-setup-storage
apt update && apt upgrade
pkg install nodejs
pkg install git 
pkg install ffmpeg
pkg install libwebp 
pkg install imagemagick
pkg install bash
git clone https://github.com/reza838/v17.git
cd v17
npm install
npm start
```
## For Windows
```bash
git clone https://github.com/reza838/v17.git
cd v7
npm install
npm start
```
## For VPS
```bash
apt install nodejs 
apt install git 
apt apt install ffmpeg 
apt apt install libwebp 
apt apt install imagemagick
apt install bash
git clone https://github.com/reza838/v17.git
cd v7
npm install
npm start
```

