
const version = `[2, 2142, 12]`
exports.version = version
